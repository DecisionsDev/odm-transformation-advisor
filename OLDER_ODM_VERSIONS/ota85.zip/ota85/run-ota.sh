$ANT_HOME/bin/ant -f ota.xml -inputhandler org.apache.tools.ant.input.SecureInputHandler run-ota
